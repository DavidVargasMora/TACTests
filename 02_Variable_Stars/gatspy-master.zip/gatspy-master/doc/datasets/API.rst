.. _datasets_API:

.. testsetup:: *

    import numpy as np
    from gatspy.datasets import *

API Documentation
=================

.. automodule:: gatspy.datasets
   :members:
