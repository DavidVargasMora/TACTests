.. _periodic_API:

.. testsetup:: *

   import numpy as np
   from gatspy.periodic import *
   import supersmoother as ssm

API Documentation
=================

.. automodule:: gatspy.periodic
   :members:
